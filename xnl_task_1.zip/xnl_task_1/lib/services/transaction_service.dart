import 'dart:async';

class TransactionService {
  Future<List<Map<String, dynamic>>> fetchTransactions() async {
    await Future.delayed(Duration(seconds: 2)); // Simulating network delay

    return [
      {"id": 1, "description": "Amazon Purchase", "amount": 50, "status": "Completed"},
      {"id": 2, "description": "Netflix Subscription", "amount": 15, "status": "Completed"},
      {"id": 3, "description": "Grocery Shopping", "amount": 120, "status": "Pending"},
    ];
  }
}
