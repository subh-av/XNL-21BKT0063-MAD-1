import 'package:web_socket_channel/web_socket_channel.dart';

class RealTimeService {
  final WebSocketChannel channel = WebSocketChannel.connect(
      Uri.parse("wss://api.example.com/realtime")
  );

  Stream get stream => channel.stream;

  void close() {
    channel.sink.close();
  }
}
