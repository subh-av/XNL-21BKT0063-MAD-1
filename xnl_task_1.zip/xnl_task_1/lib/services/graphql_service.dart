import 'package:graphql_flutter/graphql_flutter.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class GraphQLService {
  final String graphqlUrl = "https://api.example.com/graphql";
  final _storage = FlutterSecureStorage();

  GraphQLClient getClient() {
    final HttpLink httpLink = HttpLink(graphqlUrl);

    return GraphQLClient(
      link: httpLink,
      cache: GraphQLCache(),
    );
  }

  Future<List<dynamic>> fetchMarketData() async {
    final GraphQLClient client = getClient();
    final String query = """
      query {
        marketData {
          name
          price
          change
        }
      }
    """;

    final QueryResult result = await client.query(QueryOptions(document: gql(query)));

    if (result.hasException) {
      throw Exception("Failed to load market data");
    }

    return result.data?['marketData'] ?? [];
  }
}
