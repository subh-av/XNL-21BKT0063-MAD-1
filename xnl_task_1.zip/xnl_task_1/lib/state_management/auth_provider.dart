import 'package:flutter_riverpod/flutter_riverpod.dart';

// State Provider to track login status
final authProvider = StateProvider<bool>((ref) => false);
